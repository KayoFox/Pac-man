module.exports = {
    trailingSlash: true,
}
